import { initializeApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  addDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
  doc,
  setDoc
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js";

// Replace every value below with your Firebase Web App configuration.
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const authScreen = document.getElementById("authScreen");
const chatScreen = document.getElementById("chatScreen");
const usernameInput = document.getElementById("username");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const signupBtn = document.getElementById("signupBtn");
const loginBtn = document.getElementById("loginBtn");
const logoutBtn = document.getElementById("logoutBtn");
const authMessage = document.getElementById("authMessage");
const currentUser = document.getElementById("currentUser");
const messageForm = document.getElementById("messageForm");
const messageInput = document.getElementById("messageInput");
const messages = document.getElementById("messages");

signupBtn.addEventListener("click", async () => {
  const username = usernameInput.value.trim();
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  if (!username || !email || !password) {
    authMessage.textContent = "Please fill all fields.";
    return;
  }

  if (password.length < 6) {
    authMessage.textContent = "Password must be at least 6 characters.";
    return;
  }

  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    await setDoc(doc(db, "users", user.uid), {
      username,
      email,
      createdAt: serverTimestamp()
    });

    authMessage.textContent = "Account created successfully!";
  } catch (error) {
    authMessage.textContent = error.message;
  }
});

loginBtn.addEventListener("click", async () => {
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  if (!email || !password) {
    authMessage.textContent = "Enter email and password.";
    return;
  }

  try {
    await signInWithEmailAndPassword(auth, email, password);
  } catch (error) {
    authMessage.textContent = error.message;
  }
});

logoutBtn.addEventListener("click", async () => {
  await signOut(auth);
});

onAuthStateChanged(auth, (user) => {
  if (user) {
    authScreen.classList.add("hidden");
    chatScreen.classList.remove("hidden");
    currentUser.textContent = user.email;
    loadMessages();
  } else {
    chatScreen.classList.add("hidden");
    authScreen.classList.remove("hidden");
  }
});

messageForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const text = messageInput.value.trim();
  const user = auth.currentUser;

  if (!user || !text) return;

  try {
    await addDoc(collection(db, "messages"), {
      text,
      uid: user.uid,
      username: user.email.split("@")[0],
      createdAt: serverTimestamp()
    });

    messageInput.value = "";
  } catch (error) {
    console.error("Message error:", error);
  }
});

function loadMessages() {
  const messagesQuery = query(
    collection(db, "messages"),
    orderBy("createdAt", "asc")
  );

  onSnapshot(messagesQuery, (snapshot) => {
    messages.innerHTML = "";

    snapshot.forEach((messageDoc) => {
      displayMessage(messageDoc.data());
    });

    messages.scrollTop = messages.scrollHeight;
  }, (error) => {
    console.error("Firestore error:", error);
  });
}

function displayMessage(data) {
  const user = auth.currentUser;
  const messageDiv = document.createElement("div");
  messageDiv.classList.add("message");

  if (user && data.uid === user.uid) {
    messageDiv.classList.add("mine");
  }

  const name = document.createElement("div");
  name.className = "message-name";
  name.textContent = data.username || "User";

  const bubble = document.createElement("div");
  bubble.className = "message-bubble";
  bubble.textContent = data.text;

  const time = document.createElement("div");
  time.className = "message-time";

  if (data.createdAt) {
    const date = data.createdAt.toDate();
    time.textContent = date.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit"
    });
  }

  messageDiv.appendChild(name);
  messageDiv.appendChild(bubble);
  messageDiv.appendChild(time);
  messages.appendChild(messageDiv);
}
